---
name: Technical Story
about: technical work item; child of a feature; completed in one sprint
title: 'TechStory: '
labels: technical story
assignees: ''

---

As a ...
I want ...
So that ...

Acceptance Criteria:
1. ...

```[tasklist]
### Children Tasks
- [ ] Type draft title or select existing task
```
