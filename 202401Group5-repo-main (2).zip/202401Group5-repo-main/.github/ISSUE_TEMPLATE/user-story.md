---
name: User Story
about: smallest unit of functionality; child of a feature; completed in one sprint
title: 'UserStory: '
labels: user story
assignees: ''

---

As a ...
I want ...
So that ...

Acceptance Criteria:
1. ...

```[tasklist]
### Children Tasks
- [ ] Type draft title or select existing task
```
