Team Backlog (README.md)

Project Name: Scene Seeker
Movie Recommender Website

Features: (Not Implemented)
  - Website HTML, CSS
  - User login section  - home page (quiz is part of signup)
  - Quizzes
  - Seasonal quiz suggestions
  - Regular tv show/ movie quiz
  - Profile 
  - Your watchlist/wishlist
  - Feed 
  - Other people's stuff
  - Animation panel for trending/hot movies

Menu top bar (on every page) 

TO-DO:

  - SQLite -> (Michael & Shambhavi)
  - Store:
    - Private:  username, email password, security questions
    - Public: watchlist, wishlist, preferred genre + actors/actress, Reviews from users

  - IMDb API (API that calls to a database) -> (Md & Alec)
  - Intermediate script (Python)
    - Calls IMDb API for all movie-related information
    - Flask
   
  - Quizzes -> (Llorenzo & Kevin & ~Shambhavi~)
    
  - Front-end -> (Arman & Ismael)
    - HTML, CSS, JavaScript?
    - Bootstrap (Extension of CSS)

